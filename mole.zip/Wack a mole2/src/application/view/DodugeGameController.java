package application.view;

import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

public class DodugeGameController {

	Boolean finished = false;
	Boolean started = true;
	public int score = 0;
	public int timerInt = 60;
	public Button moleButton;
	public ImageView moleView;
	public TextArea topText;




	public void handleButton() {
		if(started == true) {
			this.timerMethod();
			started = false;
		}
		if(finished == false) {
			score++;
		}
		int r1 = (int)(Math.random() * 10);
		int r2 = (int)(Math.random() * 5);
		GridPane.setConstraints(moleView, r1, r2);
		GridPane.setConstraints(moleButton, r1, r2);
		topText.setText("Score: "  + score + "                Wack a Mole             Time Remaining: "
				+ timerInt);
	}

	public void timerMethod() {
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				timerInt -=1;
				topText.setText("Score: "  + score + "                Wack a Mole             Time Remaining: "
						+ timerInt);
				if(timerInt < 0) {
					topText.setText("GameOver!                  Final Score: " + score);
					finished = true;
				}
			}
		};
		timer.scheduleAtFixedRate(task, 0, 1000);
	}

}
