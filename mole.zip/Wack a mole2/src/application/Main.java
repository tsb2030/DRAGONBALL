package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class Main extends Application {

	private Stage primaryStage;
	private BorderPane rootLayout;
	public Boolean isStart = false;
	public Button backButton;



	MediaPlayer player;

	@Override
	public void start(Stage primaryStage) {
		try {
			this.primaryStage = primaryStage;
			this.primaryStage.setTitle("Address App");

//			게임창
			initRootLayout();

//			백 버튼 구현
			backButton = new Button("Back");
			backButton.setLayoutX(50.0);
			backButton.setLayoutY(50.0);
			backButton.setStyle(STYLESHEET_MODENA);
			backButton.setVisible(true);

			/*
			 * Media music = new Media(""); player = new MediaPlayer(music);
			 * player.setAutoPlay(true); player.setVolume(1);
			 *
			 */

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//게임 창
	public void initRootLayout() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/DodugeGame.fxml"));
			AnchorPane DodugeGame = (AnchorPane) loader.load();

			Scene scene = new Scene(DodugeGame);
			primaryStage.setScene(scene);
			primaryStage.show();



		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void showPersonOverview() {
		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/DodugeGame.fxml"));
			AnchorPane DodugeGame = (AnchorPane) loader.load();

			rootLayout.setCenter(DodugeGame);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void showIntroview() {
		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/Intro.fxml"));
			AnchorPane introView = (AnchorPane) loader.load();

			rootLayout.setCenter(introView);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	메인 스테이지를 반환한다. ...?
	public Stage getPriStage() {
		return primaryStage;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
